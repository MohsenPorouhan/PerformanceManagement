# AspNetCoreDapperAsyncDemo
The blog post for this project can be found here: [Using Dapper Asynchronously in ASP.NET Core 2.1](https://exceptionnotfound.net/using-dapper-asynchronously-in-asp-net-core-2-1/)
